(function($){
"use strict";
	$(function(){
		$('#menu').slicknav(
				{
					label: '',
					// prependTo:'',
				}
			);
		});


//if($("#googleMap")[0]) { 

//	function initialize() {
	
//	  var mapProp = {
//	    center:new google.maps.LatLng(37.331401462544335,-121.89474478205568),
//	    zoom:12,
//	    mapTypeId:google.maps.MapTypeId.ROADMAP
//	  };
	  
//	  var map=new google.maps.Map(document.getElementById("googleMap"), mapProp);
//	} 
//	google.maps.event.addDomListener(window, 'load', initialize);
// }


 console.log("Hey") ;
})(jQuery)
